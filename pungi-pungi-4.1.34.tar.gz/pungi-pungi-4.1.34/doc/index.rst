.. Pungi documentation master file, created by
   sphinx-quickstart on Thu Jul  2 08:11:04 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Pungi's documentation!
=================================

Contents:

.. toctree::
    :maxdepth: 2

    about
    phases
    format
    configuration
    scm_support
    messaging
    gathering
    comps
    contributing
    testing
    multi_compose
